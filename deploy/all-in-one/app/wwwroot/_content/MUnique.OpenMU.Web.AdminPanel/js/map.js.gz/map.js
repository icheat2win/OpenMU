﻿// plain javascript to make JS Interop easier

function GetMapHostBoundingClientRect() {
    return document.getElementsByClassName("map-host")[0].getBoundingClientRect();
}
